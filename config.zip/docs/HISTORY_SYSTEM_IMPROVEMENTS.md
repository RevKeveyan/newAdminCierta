# Улучшения системы истории LoadHistory

## Проблема

Ранее при создании load'а в LoadHistory записывались все поля с null значениями, что было неэффективно и неинформативно.

## Решение

### 1. Улучшенная логика создания истории

#### При создании load'а:
```javascript
// ❌ Раньше (плохо)
await this.createHistoryRecord(saved._id, 'created', req.user?.id, req.body);
// Создавало записи типа: { field: "vin", oldValue: null, newValue: "1HGBH41JXMN109186" }

// ✅ Теперь (хорошо)
await this.createHistoryRecord(saved._id, 'created', req.user?.id, []);
// Создает только: { action: "created", changedBy: userId, changes: [] }
```

#### При обновлении load'а:
```javascript
// ✅ Записываются только реальные изменения
const changes = this.getChanges(oldDoc, req.body);
// Фильтруются пустые изменения
const filteredChanges = changes.filter(change => 
  change.oldValue !== change.newValue && 
  (change.oldValue !== null || change.newValue !== null)
);
```

### 2. Умное сравнение значений

```javascript
compareValues(oldValue, newValue) {
  // Пропускаем null/undefined пары
  if ((oldValue === null || oldValue === undefined) && 
      (newValue === null || newValue === undefined)) {
    return false;
  }
  
  // Объекты сравниваем через JSON.stringify
  if (typeof oldValue === 'object' && typeof newValue === 'object') {
    return JSON.stringify(oldValue) !== JSON.stringify(newValue);
  }
  
  return oldValue !== newValue;
}
```

### 3. Фильтрация служебных полей

```javascript
// Пропускаем служебные поля MongoDB
if (['_id', 'createdAt', 'updatedAt', '__v'].includes(key)) {
  return;
}
```

## Результаты улучшений

### ✅ Что изменилось:

1. **При создании load'а:**
   - LoadHistory содержит только `action: "created"` и `changedBy`
   - Нет детальных изменений (пустой массив `changes: []`)
   - Статистика создания сохраняется для аналитики

2. **При обновлении load'а:**
   - Записываются только реально измененные поля
   - Фильтруются null → null изменения
   - Игнорируются служебные поля MongoDB

3. **При удалении load'а:**
   - Записывается `action: "deleted"`
   - Сохраняется информация о том, кто удалил

### 📊 Примеры LoadHistory записей:

#### Создание load'а:
```json
{
  "loadId": "507f1f77bcf86cd799439011",
  "action": "created",
  "changedBy": "507f1f77bcf86cd799439012",
  "changes": []
}
```

#### Обновление load'а:
```json
{
  "loadId": "507f1f77bcf86cd799439011", 
  "action": "updated",
  "changedBy": "507f1f77bcf86cd799439012",
  "changes": [
    {
      "field": "status",
      "oldValue": "Listed",
      "newValue": "Dispatched"
    },
    {
      "field": "value",
      "oldValue": 1000,
      "newValue": 1500
    }
  ]
}
```

#### Обновление статуса:
```json
{
  "loadId": "507f1f77bcf86cd799439011",
  "action": "status_updated", 
  "changedBy": "507f1f77bcf86cd799439012",
  "changes": [
    {
      "field": "status",
      "oldValue": "Dispatched", 
      "newValue": "Picked up"
    }
  ]
}
```

## Преимущества новой системы

### 🚀 Производительность:
- Меньше записей в LoadHistory
- Быстрее запросы к истории
- Экономия места в базе данных

### 📈 Аналитика:
- Четкое разделение создания и изменений
- Точная статистика по действиям пользователей
- Возможность отслеживания активности

### 🔍 Отладка:
- Чистая история изменений
- Легко найти реальные изменения
- Понятная структура данных

## Рекомендации по использованию

### 1. Для статистики создания:
```javascript
// Подсчет созданных load'ов пользователем
const createdLoads = await LoadHistory.countDocuments({
  action: 'created',
  changedBy: userId
});
```

### 2. Для отслеживания изменений:
```javascript
// Получение истории изменений load'а
const loadHistory = await LoadHistory.find({
  loadId: loadId,
  action: { $in: ['updated', 'status_updated'] }
}).sort({ createdAt: -1 });
```

### 3. Для аналитики активности:
```javascript
// Статистика по действиям
const activityStats = await LoadHistory.aggregate([
  {
    $group: {
      _id: { action: "$action", user: "$changedBy" },
      count: { $sum: 1 }
    }
  }
]);
```

## Миграция существующих данных

Если у вас уже есть LoadHistory с null значениями, можно очистить их:

```javascript
// Удалить записи с пустыми изменениями при создании
await LoadHistory.deleteMany({
  action: 'created',
  'changes.field': { $exists: true }
});

// Или обновить существующие записи
await LoadHistory.updateMany(
  { action: 'created' },
  { $set: { changes: [] } }
);
```

## Заключение

Новая система LoadHistory:
- ✅ Эффективна по производительности
- ✅ Информативна для аналитики  
- ✅ Легка в использовании
- ✅ Масштабируема для больших объемов данных
